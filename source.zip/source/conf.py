# -*- coding: utf-8 -*-
#
# conf.py
#
# Documentation options

# General information
project = 'NewCo Runbook'
copyright = '2023, David Greene'
author = 'David Greene'
# Version information
# The short X.Y version.
version = '1.0'
# The full version, including alpha/beta/rc tags.
release = '1.0.0'

# Sphinx extensions
extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.doctest',
    'sphinx.ext.intersphinx',
    'sphinx.ext.todo',
    'sphinx.ext.coverage',
    'sphinx.ext.mathjax',
    'sphinx.ext.napoleon',
    'sphinx.ext.linkcode',
]

# Napoleon settings
napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = True

# Intersphinx mapping
intersphinx_mapping = {
    'python': ('https://docs.python.org/3/', None),
}

# Other settings
master_doc = 'index'
extensions = []
templates_path = ['_templates']
exclude_patterns = []
html_theme = 'renku'
html_static_path = ['_static']
html_logo = '_static/logo.png'
html_favicon = '_static/favicon.ico'
html_show_sourcelink = False
html_show_sphinx = False
html_show_copyright = True
html_last_updated_fmt = '%b %d, %Y'
html_use_modindex = False
html_use_index = False
html_show_sphinx = False
html_show_copyright = True
html_last_updated_fmt = '%b %d, %Y'
html_use_modindex = False
html_use_index = False
html_sidebars = {
    'default': [
        ['toctree', {
            'maxdepth': 10,
            'expandable': True,           
        }],
    ],
}

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration





# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

# Suggestions
# To use the default Sphinx TOC instead of the Word document TOC, remove the `contents` directive from your RST file and set the `tocdepth` variable to the desired level of depth for the TOC in your `conf.py` file. For example, to include all headings up to and including level 3, you would set `tocdepth = 3`.

# To customize the appearance of the TOC, you can use the `toctree` directive. For more information on the `toctree` directive, please see the Sphinx documentation: https://www.sphinx-doc.org/en/master/usage/restructuredtext/directives.html

