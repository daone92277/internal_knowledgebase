import sys
from PyQt5.QtWidgets import *

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Sphinx Program")

        self.text_edit = QTextEdit()
        self.text_edit.setAcceptRichText(False)

        self.open_button = QPushButton("Open")
        self.open_button.clicked.connect(self.open_rst_document)

        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.save_rst_document)

        self.delete_button = QPushButton("Delete")
        self.delete_button.clicked.connect(self.delete_rst_document)

        self.create_button = QPushButton("Create")
        self.create_button.clicked.connect(self.create_rst_document)

        self.layout = QVBoxLayout()
        self.layout.addWidget(self.text_edit)
        self.layout.addWidget(self.open_button)
        self.layout.addWidget(self.save_button)
        self.layout.addWidget(self.delete_button)
        self.layout.addWidget(self.create_button)

        self.central_widget = QWidget()
        self.central_widget.setLayout(self.layout)

        self.setCentralWidget(self.central_widget)

    def open_rst_document(self):
        file_name = QFileDialog.getOpenFileName(self, "Open RST Document", ".", "RST Files (*.rst)")

        if file_name:
            with open(file_name, "r") as f:
                self.text_edit.setText(f.read())

    def save_rst_document(self):
        file_name = QFileDialog.getSaveFileName(self, "Save RST Document", ".", "RST Files (*.rst)")

        if file_name:
            with open(file_name, "w") as f:
                f.write(self.text_edit.toPlainText())

    def delete_rst_document(self):
        file_name = QFileDialog.getOpenFileName(self, "Delete RST Document", ".", "RST Files (*.rst)")

        if file_name:
            msg_box = QMessageBox()
            msg_box.setText(f"Are you sure you want to delete the following RST document:\n\n{file_name}")
            msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            ret = msg_box.exec()

            if ret == QMessageBox.Yes:
                os.remove(file_name)

    def create_rst_document(self):
        title = input("Enter the title of the new RST document: ")

        if title:
            path_to_new_rst_document = Path(f"{title}.rst")

            with open(path_to_new_rst_document, "w") as f:
                f.write(f"# {title}")

            self.text_edit.clear()
            self.text_edit.setText(f"# {title}")

if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()

    app.exec_()
