Monitoring Handbook

Version 1.0

.. _section-1:

.. _section-2:

.. _section-3:

.. _section-4:

 
=

Change History 
---------------

+------+-----------+--------------+-------------------+--------------+
| Ver  | Date      | Prepared/    | Reason and        | Internally   |
| sion | Created/  | Modified     | Details of Change | Reviewed By  |
|      | Changed   |              |                   |              |
| #    |           | By           |                   |              |
|      | (         |              |                   |              |
|      | MM/DD/YY) |              |                   |              |
+======+===========+==============+===================+==============+
| V    | 0         | HIG Leads,   | Initial Version   | Patturi,     |
| 1.0  | 3/05/2023 | PS Alert &   |                   | Kishore      |
|      |           | Monitoring   |                   |              |
|      |           | Team         |                   |              |
+------+-----------+--------------+-------------------+--------------+


Purpose of the Document 
------------------------

The document provides summary of various monitoring and alerting steps
tools and procedures instrumented on the applications within Personal
Lines.

+----+-----------------------------------------------+-----------------+
| ** | **Sanity Checks**                             | **Hartford &    |
| SR |                                               | Shared          |
| .1 |                                               | Mailbox**       |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Sanity Check 
-------------

**Descriptions** – This task is performed to check the overall
Application Availability. Team checks the following functionalities a)
Quote creation for Auto & Home LOB is working fine, b) Policy
Monitoring, c) Sales Router getting routed to each zip codes, d) Billing
URL, e) CSR Monitoring for Policy & Billing.

-  Quote creation for Auto & Home LOB:

URL: https://www.thehartford.com/

   Credentials: Not needed, one can directly launch website by entering
   above URL. You need to provide Zip code for Auto and Home product and
   verify if Upfront Product Selection Page is getting loaded
   successfully. Please find the list of Zip codes used against the
   NewCo States:

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image1.emf
      :width: 6.875in
      :height: 0.42708in

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image2.png
      :width: 6.90625in
      :height: 0.40625in

LOB Personal Auto – SS

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image3.png
   :width: 6.87433in
   :height: 3.37766in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image4.png
   :width: 6.83289in
   :height: 3.4859in

LOB Personal Home – SS

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image5.png
   :width: 6.875in
   :height: 3.55167in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image6.png
   :width: 6.875in
   :height: 3.5406in

.. _section-6:

Sales Router:
~~~~~~~~~~~~~

URL: https://www.thehartford.com/

Credentials: Not needed, we can directly start as below

**Steps:**

-  Please enter any Zip code other than NewCo Go-LIVE States e.g., CA -
   90210, click on Start Quote button.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image7.png
   :width: 6.875in
   :height: 3.32679in

-  User should be navigated to the NowCo Quote page

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image8.png
   :width: 6.4442in
   :height: 3.31549in

Billing URL: 
~~~~~~~~~~~~~

URL: https://internalbuy.thehartford.com/billing/default.aspx

-  You need to verify whether the URL is accessible & loading
   successfully

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image9.png
   :width: 6.28421in
   :height: 2.7291in

User Admin: 
~~~~~~~~~~~~

URL: https://internalbuy.thehartford.com/UserAdminPolicy/default.aspx

-Please verify whether the URL is accessible & loading User Admin site

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image10.png
   :width: 6.22579in
   :height: 3.20814in

Internal Policy
~~~~~~~~~~~~~~~

URL: https://internalbuy.thehartford.com/policy/express.aspx

-Please verify whether the URL is accessible & loading the page

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image11.png
   :width: 6.27572in
   :height: 3.23386in

Policy Monitoring for CSR User
------------------------------

   URL:
   https://smfederation.thehartford.com/affwebservices/public/saml2sso?SPID=DuckCreekPolicy

-Search any existing PROD Policy number and it should be searchable. One
needs to have CSR access to validate this.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image12.png
   :width: 6.19792in
   :height: 4.09375in

Steps for View policy, View Policy Details, and Customer 360 
-------------------------------------------------------------

#. You need to navigate or load Transact page when user search for the
Policy

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image13.png
   :width: 6.08333in
   :height: 4.31389in

#. Click on ‘Policy Actions’ dropdown which is present on the
top-right side of page

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image14.png
   :width: 6.04167in
   :height: 4.01389in

#. click on ‘View Policy details and verify all section like – Notes,
etc.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image15.png
   :width: 6.375in
   :height: 4.36458in

#. click on View Customer 360​ and verify Billing Card, Policy Card
----------------------------------------------------------------------

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image14.png
   :width: 6.30208in
   :height: 4.01389in

#. Policy Card:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image16.png
   :width: 6.61458in
   :height: 4.54167in

#. Billing Card

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image17.png
   :width: 6.53125in
   :height: 4.62917in

#. Search click on Party and search Party Name.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image18.png
   :width: 6.32292in
   :height: 4.39583in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image19.png
   :width: 6.48958in
   :height: 3.98958in

Billing Monitoring *for CSR User*
---------------------------------

-Search for Billing Account (mentioned below URL) and it should be
searchable

**URL** : https://internalbuy.thehartford.com/billing/default.aspx

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image20.png
   :width: 6.84375in
   :height: 4.03125in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image21.png
   :width: 6.875in
   :height: 3.55694in

**B) Policy Batches**

**Description** – Team monitors **PL NEWCO PROD ALERTS** mailbox for any
Policy batch related errors

.

**C)** **Billing Batches**

**Description -** Team monitors **PL NEWCO PROD ALERTS** mailbox for any
Billing batch related errors

**D)** **Party Error**

**Description -** Team checks & monitors DCOD Error Log table to get a
Party Error details.

+----+-----------------------------------------------+-----------------+
| ** | **Core Logic & BRCC Home Inspection**         | **CoreLogic     |
| SR |                                               | Daily Jobs &    |
| .2 |                                               | Alert Mailbox** |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Corelogic and BRCC Home Inspection
----------------------------------

**Description -** Team validates the list of Corelogic vendor files
successfully processed through CoreLogic daily job. Along with the same,
team verifies the count of successful home inspection balancing from
BRCC. In case of any issue found, team shares the failures with
respective POC.

Steps used: Post 6:00 AM EST daily, team verifies DCOD Prod Alerts
mailbox for the counts shared by Corelogic and Home Inspection team:

Corelogic:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image22.png
   :width: 6.5in
   :height: 2.72431in

Home Inspection:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image23.png
   :width: 6.5in
   :height: 2.20208in

-  After that, team reconfirms the count in Database. Home Inspection
   balancing from BRCC can also be found from AFS. Failure can be found
   from Carrier_2ExtendedLogging_Messages for Level 2 XML for DocGen
   service

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image24.png
   :width: 6.5in
   :height: 0.82708in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image25.png
   :width: 2.98958in
   :height: 2.25in

+----+-----------------------------------------------+-----------------+
| ** | **NJ Carco**                                  | **Sql &         |
| SR |                                               | Spreadhseet**   |
| .3 |                                               |                 |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

NJ Carco
~~~~~~~~

**Description -** Implementation team is working on enhancing NJ Carco
Batch job to handle the scenario where Policy Number is blank and to
schedule the job not to run on weekends as per vendor file delivery.
Team validates the batch job on daily basis to identify if any blank
Policy number is present in the file. In case of exception team reports
to the vendor for recovery.

Approach

i) Team checks the Success/Failures for CarCo batch in the extended
   logging messages table.

..

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image26.png
      :width: 6.5in
      :height: 1.01319in

ii) Validates the daily file sent in following path:
    `\\\\ad1.prod\\hig\\PL\\newco-prod\\DCExchange\\CarCo\\Inbound <file://ad1.prod/hig/PL/newco-prod/DCExchange/CarCo/Inbound>`__,
    open the spreadsheet for a particular date and check if blank policy
    number field is present and prepares the report accordingly.

..

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image27.png
      :width: 2.04167in
      :height: 1.90625in

+----+-----------------------------------------------+-----------------+
| ** | **Batch Summary**                             | **Splunk        |
| SR |                                               | Dashboard &     |
| .4 |                                               | SQL**           |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

App2App Batches
~~~~~~~~~~~~~~~

**Description -** This dashboard is used to monitor all the 5 App2App
batches: Stager, Transient, Persistent, Generator, Balancer. We can see
the timings of all the batches, logs of each run of all the batches, the
error (and its details) which we receive for each batch. Also, the
Autosys logs which trigger these batches can be monitored through the
dashboard.

Dashboard Link: *Search \| Splunk 9.0.2209.4 (splunkcloud.com)*

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image28.png
   :width: 5.61458in
   :height: 2.40556in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image29.png
   :width: 6.26823in
   :height: 2.86674in

-  Steps taken when we receive failure in the App2App Batches:

i) Whenever, we encounter any Stager failure like SSIS Job goes on HOLD
   due to duplicate transaction in the Feed file and the App2App Prod
   DB, then we recognize

..

   the duplicate transactions and raise ODCH to ignore the transactions
   causing the issue and resume the Job.

ii)  When we encounter any Transient failure for a particular
     transaction, team analyzes the issue and raise Production defect.

iii) At the time of Persistent failure, we raise RITM to switch ON the
     Persistent in App2App App_config table and raise RITM to recover
     the transactions which are failed due to the Persistent failure.

iv)  For Generator, when we have any report failure, we analyze the
     cause of the failure and raise the Prod defect and retrigger the
     report generation for that date by raising RITM. For transaction
     level failure in Generator Layer, we check the REPORT_EXCEPTION
     table and analyze the issue and accordingly raise defect.

B) **NPPS Batches**

..

   **Description -** This dashboard is used to monitor all the 5 NPPS
   batches: Stager, Transformer, Generator, Balancer, RDM Refresh. We
   can see the execution details of all these batches, logs of each run
   of all the batches, the error (and its details) which we receive for
   each batch. Also, the Autosys logs which trigger these batches can be
   monitored through the dashboard.

   ‘NPPS - Personal Lines Batch Errors’ Splunk Link: `Search \| Splunk
   9.0.2209.4
   (splunkcloud.com) <https://thehartford.splunkcloud.com/en-US/app/HIG_APP_PL/search?s=%2FservicesNS%2Fnobody%2FHIG_APP_PL%2Fsaved%2Fsearches%2FNPPS%2520-%2520%2520Personal%2520Lines%2520Batch%2520Errors&display.page.search.mode=verbose&dispatch.sample_ratio=1&workload_pool=standard_perf&q=search%20index%3Dapp_pl%0A(%20source%3DD%3A%5C%5Cpl%5C%5CNPPS%5C%5CPROD%5C%5CLogs%5C%5CBalancer%5C%5CBalancer.json%0AOR%20source%3DD%3A%5C%5Cpl%5C%5CNPPS%5C%5CPROD%5C%5CLogs%5C%5CStager%5C%5CStager.json%0AOR%20source%3DD%3A%5C%5Cpl%5C%5CNPPS%5C%5CPROD%5C%5CLogs%5C%5CFileGenerator%5C%5CFileGenerator.json%0AOR%20source%3DD%3A%5C%5Cpl%5C%5CNPPS%5C%5CPROD%5C%5CLogs%5C%5CTransformer%5C%5CTransformer.json%20)%0Alevel%20IN%20(%22ERROR%22%2C%20%22FATAL%22)&earliest=-24h%40h&latest=now&sid=1678351237.23623_E9B61837-3EE4-4015-AD65-57E9E0F3BEFF>`__

-  Steps taken when we receive failure in the NPPS Batches:

i)   Whenever, we encounter any Stager failure like SSIS Job goes on
     HOLD due to duplicate transaction in the Feed file and the NPPS
     Prod DB, then we perform the analysis to identify the duplicate
     transactions. Once done we raise ODCH to ignore the transactions
     causing the issue and resume the Job.

ii)  When we encounter any **Transformer** failure for a particular
     transaction, team analyzes the issue and raise Prod defect.

iii) For File Generator, when we have any NPPS report failure, we
     analyze the cause of the failure and raise the Prod defect and
     retrigger the report generation for that date by raising RITM.

C) **Infoservice (Auto) Data**

**Description -** The dashboard that is used to monitor all the
Infoservice Auto batch job errors.

We can see the timings of all the batches, logs of each run of all the
batches, the error (and its details) which we receive for each batch.
Also, the Autosys logs which trigger these batches can be monitored
through the dashboard.

Note - The Infoservice file gets triggered only once in a week that is
on Sunday unless we make manual intervention to run the Infoservice job.

Dashboard link-
https://thehartford.splunkcloud.com/en-US/app/HIG_APP_PL/auto_infoservice_batch_dashboard__prod?form.field1.earliest=-7d%40h&form.field1.latest=now

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image30.png
   :width: 6.5in
   :height: 3.02083in

-  Steps taken when we receive failure in the Infoservice Batches:

..

   i) Whenever we encounter that the Infoservice Feed file is present in
   Inbound folder but not triggered then team will analyze the issue and
   raise RITM to trigger the Infoservice job.

   ii) If we encounter any Infoservice errors then team will analyze the
   issue and take the necessary actions like raising the defects,
   discussion with the appropriate teams or raising RITM.

**D) Insights Purge**

**Description -** This data is collected to monitor the Weekly Insights
Purge activity which purges the data from the Custom table present in
Data Insights database.

-  Approach: It is collected using SQL scripts

Report Screenshot

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image31.png
   :width: 6.875in
   :height: 0.27031in

+----+-----------------------------------------------+-----------------+
| ** | **Real Time DP/APIC, Claims & Balancing**     | **Email &       |
| SR |                                               | Splunk          |
| .4 |                                               | Dashboard**     |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Real Time DP/APIC, Claims & Balancing
-------------------------------------

A) **DP/APIC (ESIGN (DP/ APIC), HomeRoof, HomeGrid), Agero, Safelight,
   APIC - newco policy search/inquiry/ info, Balancing**

**Description -** Team captures summary of Errors for Real Time APIs
like – DP/APIC, Claims & Balancing. Team performs analysis & raise
defects wherever required. Furthermore, Tracking of Defects is being
taken care.

*Structure of this table is as below –*

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image32.png
      :width: 6.5in
      :height: 1.93889in

-  Steps as Follows –

..

   | i) Collect alerts from PL NEWCO Prod Alert mailbox using APIC and
     WSM.
   | ii) Get the service name and error message from the mail for
     reporting.

B) **Claims Stat API Dashboard**

..

   **Description - This dashboard is used to monitor all the claims
   errors.**

   **Claims Stat API Dashboard Splunk Link :** `Claims Stat API
   Dashboard \| Splunk 9.0.2209.4
   (splunkcloud.com) <https://thehartford.splunkcloud.com/en-US/app/HIG_APP_PL/claims_stat_api_dashboard?form.field2.earliest=-24h%40h&form.field2.latest=now&form.field1.earliest=-24h%40h&form.field1.latest=now&form.field4.earliest=-24h%40h&form.field4.latest=now&form.field3.earliest=-24h%40h&form.field3.latest=now&form.field5.earliest=-24h%40h&form.field5.latest=now&form.field6.earliest=-24h%40h&form.field6.latest=now&form.field14.earliest=-24h%40h&form.field14.latest=now&form.field15.earliest=-24h%40h&form.field15.latest=now&form.field16.earliest=-24h%40h&form.field16.latest=now&form.field17.earliest=-24h%40h&form.field17.latest=now>`__

   |image1|\ |image2|

-  Steps taken when we receive claims Error:

| Whenever, we encounter any claims Error (with error codes:
  501,502,503,504,505,506)
| team analyzes the issue and update the below tracker accordingly. Also
  we raise Prod defect if needed.
| `ClaimsStatAPI_Tracker.xlsx
  (sharepoint.com) <https://thehartford.sharepoint.com/:x:/r/sites/NewCoProgram/_layouts/15/doc2.aspx?sourcedoc=%7B0F1D3B85-F4B6-45FA-A0FE-A6CA46112918%7D&file=ClaimsStatAPI_Tracker.xlsx&action=default&mobileredirect=true&isSPOFile=1&clickparams=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA3MzEwMTAwNSIsIkhhc0ZlZGVyYXRlZFVzZXIiOmZhbHNlfQ%3D%3D&cid=750af619-d834-4e0b-8c1c-45cc43cb6843>`__

+----+-----------------------------------------------+-----------------+
| ** | **Billing Monitoring Checklist**              | **SQL Query,    |
| SR |                                               | AFS, MFTPortal  |
| .5 |                                               | & Email**       |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Billing Checklist
-----------------

   **Description –** Team Monitor Billing Transactions for Newco
   Application. More Insights below

i) Section 1: All Processing exception which got logged in last 24 hours
in DC_BIL_ProcessingExceptions for Billing. Which give us information
for missing transactions in Billing and any critical issue occurring in
system.

ii) SECTION 2: Payment Batch Failure details (DC_BIL_PaymentBatch), look
for payment batch failure in last 24 hrs. (from Monday look or last 72
hrs.)

iii) SECTION 3: Bank ID issue need to run in morning to validate any
bank id conflict, in case we got any EFTTransmissionId with bankID
conflict we must raise ODCH request to correct the same.

iv) SECTION 4: Payment wallet issue where payment id is deleted, but
collection not set to paper. In such case we must report affected
account to Business to take appropriate actions.

v) SECTION 5: Lockbox monitoring, we can find any pending lockbox file
.LBX which is not yet processed from AFS folder, by logon to Microsoft
Azure Storage Explorer on file location.

vi) SECTION 6: We can check the count of Billing docs sent to BRCC for
printing, and failures as well in case there.

vii) SECTION 7: Scheduled Activity stuck with 'I' status: To check
whether the jobs were in complete status for stuck in between process.

viii) SECTION 8: Monitor Billing jobs from PL NEWCO ALERT shared mailbox
for last 24 hours.

and as per the alerts we got we can validate the logs by manually
checking AFS logs files.

A) **Billing Checklist Template**

+---------------+--------------+--------------+--------+------+------+
| **Billing     |              |              |        |      |      |
| Monitoring    |              |              |        |      |      |
| Check List**  |              |              |        |      |      |
+===============+==============+==============+========+======+======+
| **Processing  | We received  |              |        |      |      |
| Exception**   | alert for:   |              |        |      |      |
|               | [Refer       |              |        |      |      |
|               | Section 1]   |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
|               | **Excepti    | **ExceptionR | **D    | **Co | **   |
|               | onTypeCode** | eferenceId** | escrip | mmen | Assi |
|               |              |              | tion** | ts** | gned |
|               |              |              |        |      | Te   |
|               |              |              |        |      | am** |
+---------------+--------------+--------------+--------+------+------+
|               | <Except      | <Exception   | <      | <D   | <    |
|               | ionTypeCode> | ReferenceId> | Descri | efec | Team |
|               |              |              | ption> | tID> | who  |
|               |              |              |        |      | wor  |
|               |              |              |        |      | king |
|               |              |              |        |      | on   |
|               |              |              |        |      | Def  |
|               |              |              |        |      | ect> |
+---------------+--------------+--------------+--------+------+------+
|               | <Except      | <Exception   | <      | <D   | <    |
|               | ionTypeCode> | ReferenceId> | Descri | efec | Team |
|               |              |              | ption> | tID> | who  |
|               |              |              |        |      | wor  |
|               |              |              |        |      | king |
|               |              |              |        |      | on   |
|               |              |              |        |      | Def  |
|               |              |              |        |      | ect> |
+---------------+--------------+--------------+--------+------+------+
| **Payment     | [Refer       |              |        |      |      |
| Batch         | Section 2]   |              |        |      |      |
| Failure**     |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **Validate    | [Refer       |              |        |      |      |
| any bank id   | Section 3]   |              |        |      |      |
| conflict**    |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **Payment     | [Refer       |              |        |      |      |
| wallet issue  | Section 4]   |              |        |      |      |
| where payment |              |              |        |      |      |
| id is         |              |              |        |      |      |
| deleted, but  |              |              |        |      |      |
| collection    |              |              |        |      |      |
| not set to    |              |              |        |      |      |
| Paper**       |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **Lockbox     | [Refer       |              |        |      |      |
| monitoring    | Section 5]   |              |        |      |      |
| queries**     |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **BRCC        | [Refer       |              |        |      |      |
| Balancing     | Section 6]   |              |        |      |      |
| Failure       |              |              |        |      |      |
| (Billing)**   |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **Scheduled   | [Refer       |              |        |      |      |
| Activity      | Section 7]   |              |        |      |      |
| stuck with    |              |              |        |      |      |
| 'I' status**  |              |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+
| **Billing     | [Refer       |              |        |      |      |
| Jobs**        | Section 8]   |              |        |      |      |
+---------------+--------------+--------------+--------+------+------+

+----+-----------------------------------------------+-----------------+
| ** | **3PD Services**                              | **SQL Query &   |
| SR |                                               | Splunk          |
| .6 |                                               | Dashboard**     |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

3PD Services
------------

**Description -** There are 65+ third-party services. Team checks the
health of all the services on daily basis from the previous day 4 AM EST
to the next day 4 AM EST.

Data is extracted from Carrier_ExtendedLogging_Messages table of
consolidated database and thirdpartyxmldata table of staging database.
Team generates a report regarding the total calls, total number of
failures and the type of error/error message for all the third-party
services. Services are sorted in descending order of the failures.

Based on the number of failures, Team performs Analysis and raises
defect if required or follow up with the vendor.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image35.png
   :width: 6.5in
   :height: 2.89931in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image36.png
   :width: 6.5in
   :height: 2.58889in

+----+-----------------------------------------------+-----------------+
| ** | **Additional Services - Splunk Dashboard**    | **Splunk**      |
| SR |                                               |                 |
| .7 |                                               |                 |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Duck Creek Splunk Dashboard – Performance
-----------------------------------------

   **Description -** This dashboard provides the performance metrices
   (in percentage) of processor time, memory usage, used space, average
   %CPU over time and average % memory over time for individual
   hostname.

URL: `Performance Dashboard \| Splunk 9.0.2209.3
(splunkcloud.com) <https://dct.splunkcloud.com/en-US/app/test_iFrameDemo/performance_dashboard?form.target_domain=dct_metrics_prod&form.hostname_ui=UEPRD28APP23>`__

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image37.png
   :width: 6.5in
   :height: 3.14236in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image38.png
   :width: 6.5in
   :height: 1.74792in

A) **Duck Creek Splunk Dashboard – Event**

..

   **Description -** Team monitor Duck Creek Application events through
   this dashboard. It provides Event Counts by Application over Time,
   Event Message %, Event Count by Application, Event Details.

URL: `Event Dashboard \| Splunk 9.0.2209.3
(splunkcloud.com) <https://dct.splunkcloud.com/en-US/app/test_iFrameDemo/event_dashboard?form.time_ui.earliest=-15m&form.time_ui.latest=now&form.target_domain=dct_*_prod&form.hostname_ui=*&form.event_detail_search=*&form.log_severity=*&form.application_name=*&form.correlationid_search=*&form.message_title_search=*>`__

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image39.png
   :width: 6.55284in
   :height: 3.43754in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image40.png
   :width: 6.5in
   :height: 3.03125in

+----+-----------------------------------------------+-----------------+
| ** | **Renewal Batch**                             | **SQL Query**   |
| SR |                                               |                 |
| .8 |                                               |                 |
| ** |                                               |                 |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

Daily Renewal Batch monitoring
------------------------------

**Description -** Daily renewal batches are executed on policies that
renew annually or on some other recurring basis. These batches typically
consist of automated processes and scripts that run every day and are
designed to handle the various tasks and workflows involved in renewing
policies.

Some of the key tasks that may be included in daily renewal batches
include:

-  Policy renewal: The batch may be responsible for identifying policies
   that are due for renewal and automatically renewing them if the
   policyholder has not made any changes or cancelled their policy.

-  Premium calculation: The batch may calculate the premium amounts for
   each policy based on factors such as the insured value, deductible,
   and any discounts or surcharges.

**The four batches which run every day for Auto and Home policies:**

i) Auto Start batch – To process Renew-pending transactions on Auto
policies that are due for new renewals.

ii) Auto Commit batch – To issue the Renew-pending transactions on Auto
policies that are due for renewal commit.

iii) Home Start batch – To process Renew-pending transactions on Home
policies that are due for new renewals.

iv) Home Commit batch – To issue the Rene-pending transactions on Home
policies that are due for renewal commit.

**Files which get executed in Production:**

-  AutomatedProcess_Renewal_Start_Auto

-  AutomatedProcess_Renewal_Commit_Auto

-  AutomatedProcess_Renewal_Start_Home

-  AutomatedProcess_Renewal_Commit_Home

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image41.png
   :width: 3.94792in
   :height: 1.72917in

**Key Tasks:**

-  **Policy renewal task:** The policies are picked by the batches based
   on the No. of days criteria mentioned in the “RenewalDays” table in
   manuscript “Carrier_AutomatedProcess_Renewal”.

Auto policy term: 6 months, Home Policy term: 1 Year

-  **Premium calculation task**: “data.ProcessCheck” and
   “data.ProcessCheck_Commit” fields from
   “Carrier_AutomatedProcess_Renewal” manuscript are executed for the
   premium calculations.

|image3| |image4|

For Example:

When an Auto policy is of AK state,

Renew start batch must be initiated 40 days prior to the current term
expiration date.

Renew commit batch must be initiated 51 days prior to the current term
expiration date.

Similarly, when a Home policy is of AK state,

Renew start batch must be initiated 110 days prior to the current term
expiration date.

Renew commit batch must be initiated 51 days prior to the current term
expiration date.

*Failure Analysis and Recovery*:

Few policies might fail to Renew or Commit in the daily batches and must
be analyzed and recovered.

We clone the policies in Debug environment and run the batch-script on
those policies. Trace Monitor is used to analyze the failure reasons.
Also, we can check the DCOD error logs to check for reasons of failure.

Policies can either be recovered in the back end via data fix/recovery
scripts or Problem study team helps in the recovery.

*Daily Report format:*

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image44.png
   :width: 5.92708in
   :height: 2.79167in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image45.png
   :width: 5.85416in
   :height: 2.03125in

Overall, the goal of daily renewal batches is to streamline the policy
renewal process and ensure that policies are renewed on time and with
accurate information. This helps us to manage operations more
efficiently and provide better service for our customers.

+----+-----------------------------------------------+-----------------+
| ** | **System Error**                              | **Digital       |
| SR |                                               | Analytics ,     |
| .9 |                                               | Glassbox &      |
| ** |                                               | Query**         |
+====+===============================================+=================+
+----+-----------------------------------------------+-----------------+

System Errors
-------------

**A) Transaction Count from DR DB vs No. of sessions with Error Page
(It’s Not You. It’s us) for Internal/External users report**

**Description -** Team extract error page counts and percentage for
Auto, Home & Service Portal (both internal & External). Perform Analysis
for each error pages that exceeds the threshold value and raise defects
with System Error Analysis report wherever required. Moreover, Team
Monitors and assist the other team for the system error defects.

Note – We consider Data as Current day – 2 previous days

-  Steps as follows

i) Firstly, Logon to Glassbox and you can find the count
internal/External Count :

url - https://glassbox.thehartford.com/webinterface/webui/#/reports/4918

ii) PIP indicates the internal (No. of sessions with Error Page (It’s
Not You. It’s us))

   count and by adding the remaining states we get the external(No. of
   sessions with Error Page (It’s Not You. It’s us)) count.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image46.png
   :width: 6.12215in
   :height: 1.82749in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image47.png
   :width: 5.92653in
   :height: 3.04684in

-  Next , we have digital Analytics for Auto, Home & Service. Auto URL -
   https://tableau/#/site/Digital/views/KnockoutsFormErrorsReport-60days/NewCoAuto-ErrorRatesByPage?:iid=1

-  Calculate the Total Errors and User Error Rate from the above URL and

consider the PageName whose User Error rate >=2 .

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image48.png
   :width: 6.5in
   :height: 2.11806in

-  Home URL -
   https://tableau/#/site/Digital/views/NewCoHome-KnockoutFormErrors-90days/ErrorRatesbyPage?:iid=1

-  Calculate the Total Errors and User Error Rate from the above URL and
   consider the PageName whose User Error rate >=2 .

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image49.png
   :width: 6.47689in
   :height: 1.95591in

-  *Service URL -*
   https://tableau/#/site/Digital/views/NewCoServiceFormErrorReport/NewCoService-ErrorRatesByPage?:iid=1

-  Calculate the Total Errors and User Error Rate from the above URL and
   consider the PageName whose User Error rate >=2 .

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image50.png
   :width: 6.5in
   :height: 2.32292in

+----+----------------------------------------------+-----------------+
| ** | **BRCC Balancing Issues & Balancing Issues** | **Email & SQL** |
| SR |                                              |                 |
| .  |                                              |                 |
| 10 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

BRCC Balancing Issues
---------------------

   **Description -** This data is collected for the Reconciliation of
   the documents generated by BRCC and Requests made from HIG. In case
   of unexpected deviation in report and if the documents are not
   available, Team performs daily recovery or raise incident based on
   the number of instances.

-  Approach - It is collected by extracting the Report sent from BRCC
   daily and cross checked with log of requests made from HIG.

Mail screenshot:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image51.png
   :width: 6.5in
   :height: 2.03889in

Extracted RPT file from BRCC Balance Details Report

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image52.png
   :width: 6.58086in
   :height: 3.45425in

Report Screenshot

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image53.png
   :width: 5.32292in
   :height: 1.96875in

A) **Balancing Issues**

**Description -** This data is collected for Identifying the
transactions of various components like TACT, POST, DIS, App2App, NPPS,
EDO which are missing and are not balanced. Team works on Daily recovery
of missing transactions.

-  Approach: It is collected by running various SQL queries in different
   Database servers and cross validate those data.

..

   Report Screenshot

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image54.png
      :width: 6.5in
      :height: 2.51875in

+----+----------------------------------------------+-----------------+
| ** | **Certificate Upgrade**                      | **Email, RITM,  |
| SR |                                              | SharePoint**    |
| .  |                                              |                 |
| 11 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

Certificate Upgrade 
--------------------

**Description -** The purpose of monitoring Certificate validity is to
prevent the certificates from getting expired so that all the services
remain up and running.

Team monitors the validity of certificates of all data power as well as
on-prem services. Once any certificate is about to expire, or the
password needs to reset – team gets an alert in NewCoCertCommunications
and PL NewCo ProdSupport DL and acts on it accordingly.

-  Approach

i) Once team gets intimation of any certificate expiration (before 30
   days or more), they follow up with the vendor for gathering required
   data and raise RITM for Renewal. Once the certificate is installed
   before expiration date, team validates the same in web browser.

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image55.png
   :width: 5.55208in
   :height: 6in

ii) Followed by renewal, most of the time there is a deployment to
    update the new cert details in the respective layer (DataPower, F5
    etc.). Post that, team validates the third-party services traffic
    (successful calls as well as failures) to ensure the cert upgrade is
    not impacting the business by any means. For On-Prem services, we
    get reference from Splunk Dashboard as well to get service traffic.
    (PL Account Linking, Sales Router etc.).

Validations for Third Services

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image56.png
   :width: 2.89583in
   :height: 0.79167in

Validations for HIG Internal Services

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image57.png
   :width: 4.05208in
   :height: 2.1875in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image58.png
   :width: 5.51042in
   :height: 1.22917in

iii) Team validates the Glassbox sessions to ensure successful
     quote/policy creation or account linking post the upgrade.

For daily monitoring, we track all the certificate related details in
SharePoint and show those certificate details which are about to expire
in daily health report.

Link of Cert Upgrade Details:
`3PD_CertUpdates.xlsx <https://thehartford.sharepoint.com/:x:/r/sites/NewCoProgram/Execution/Production%20Support/3PD/3PD_CertUpdates.xlsx?d=wb15828149ec944d0839de4519da2359f&csf=1&web=1&e=t3yke0>`__

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image59.png
   :width: 6.5in
   :height: 0.93194in

+----+----------------------------------------------+-----------------+
| ** | **MTE Extract**                              | **MTE**         |
| SR |                                              |                 |
| .  |                                              |                 |
| 12 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

MTE Ticket Extract Report
-------------------------

   **Description -** Here, Team extracts lists of incidents raised on
   daily basis from MTE Portal. Bifurcated as Auto Generated & Self
   Service. Performs analysis if the incidence hold unknown issue.

-  Steps to create Report

i)  Go to MTE URL

ii) Search for reports in search pane and then select View/Run

..

   .. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image60.png
      :width: 2.80208in
      :height: 2.45833in

iii) Click on group, and then select “Self

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image61.png
   :width: 6.5in
   :height: 1.39931in

iv) Right click next to Number and select export -> excel option

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image62.png
   :width: 6.5in
   :height: 2.81319in

v)  |image5| Open the downloaded excel

vi) To create below table for PL NewCo PROD, follow the steps from a to
    f

+------------------------------+------------+--------------------------+
| **Source**                   | **Count of | **Reported in last 24    |
|                              | Tickets**  | Hrs. (prev. date and     |
|                              |            | current date)**          |
+==============================+============+==========================+
| Auto Generated               | A          | B                        |
+------------------------------+------------+--------------------------+
| Self-Service (User reported/ | C          | D                        |
| Virtual Agent)               |            |                          |
+------------------------------+------------+--------------------------+
| **Grand Total**              | **A+C**    | **B+D**                  |
+------------------------------+------------+--------------------------+

a) Filter, Configuration items as Prod

b) To find A, filter out records, select Ticket created date from
   April(all dates) and blanks, then apply filter on Reported method
   column-> select “Auto-generated”, write the count in place of A

c) To find B, filter out records as, select Ticket created date as prev.
   date (current date -1) and current date. In the Reported method
   column -> select “Auto-generated”, write the count in place of B

d) To find C, select Ticket created date as April(all dates) and blanks,
   then apply filter on Reported method column-> select ”Catalogue self
   -service”, “Self-service”, “Virtual agent” and “service desk phone” ,
   write the count in place of C

e) To find D, filter out records as, select Ticket created date as prev.
   date (current date -1) and current date, then apply filter on
   Reported method column-> select ”Catalogue self -service”,
   “Self-service”, “Virtual agent” and “service desk phone”, write the
   count in place of D

f) To create below table, use the same filters as are given in step e,
   and filter status based on “state” column

Note -- For DCOD stat, repeat the steps from step a to f but select
Assignment group as PL NEWCO DCOD

+----+----------------------------------------------+-----------------+
| ** | **SF Details**                               | **Duck Creek    |
| SR |                                              | Force**         |
| .  |                                              |                 |
| 13 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

SF Details 
-----------

   **Description -** Team is tracking SF tickets raised on DCT for any
   Production Issues, SQL script execution, Access etc. Also, Verifies
   if the status Defect is “Waiting on Customer” and tracks the
   progress.

-  Follow below steps to fetch SF details, note you should have access
   to SF portal for extracting this data:

i)  Login to `this <https://duckcreek.force.com/DCTSupport/s/login/>`__
    URL

ii) Navigate to ‘Customer Report’ tab as shown below:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image64.png
   :width: 5in
   :height: 1.08333in

iii) Select values as: Account Name = Hartford, Cases Created After =
     1/1/2022 & Status = take all statuses except Resolved & Closed.
     Please see image below:

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image65.png
   :width: 5in
   :height: 1.60417in

* Click on ‘Submit’ button


*  Click on ‘Download Excel’ button


* Open the downloaded excel, change font size as required and perform

    following steps:

#. Hide all the columns from ‘B’ to ‘G’, ‘I’ and ‘J’, ‘L’ , ‘M’, ‘N’


#. - Filter on column ‘K’ (Created By) and select PS Team members ONLY


#. - Select columns ‘A’, ‘H’, ‘K’ & ‘O’ and this forms our first table

   Example shown below

Note - Team follow up with DCOD team and responds if there is any SF
ticket with status as ‘Waiting On Customer’

+--------+----------+----------+-------------------------------------+
| **Case | **       | *        | **Subject**                         |
| Nu     | Status** | *Created |                                     |
| mber** |          | By**     |                                     |
+========+==========+==========+=====================================+
| 228812 | Quali    | Arka     | Unable to raise any ODCH with the   |
|        | fication | Sarkar   | xml file having tag inline          |
+--------+----------+----------+-------------------------------------+
| 228687 | Quali    | Nilesh   | Request to reset password for DR DB |
|        | fication | Datir    | (user: MayuriM)                     |
+--------+----------+----------+-------------------------------------+
| 228516 | Q        | Kishore  | Need SalesForce access to Kevin     |
|        | ualified | Patturi  | Bodie                               |
+--------+----------+----------+-------------------------------------+
| 227445 | Waiting  | Carlos   | Event Viewer Logs CC_PAYMENTS error |
|        | on       | Aponte   |                                     |
|        | Customer |          |                                     |
+--------+----------+----------+-------------------------------------+
| 225123 | In-      | Preetam  | Spike in 500 Internal Server Error  |
|        | Progress | Bharambe | on 7/22 around 5:30pm               |
+--------+----------+----------+-------------------------------------+
| 224861 | Waiting  | Carlos   | Event Viewer Logs for PROCESS_PCN   |
|        | on       | Aponte   |                                     |
|        | Customer |          |                                     |
+--------+----------+----------+-------------------------------------+
| 222889 | Dev      | Nilesh   | Fees not getting Auto WriteOff on   |
|        | elopment | Datir    | the SINV execution which scheduled  |
|        |          |          | after FCAN                          |
+--------+----------+----------+-------------------------------------+
| 222718 | Waiting  | Akila    | Insights - Timeout error spike      |
|        | In       | Raj      |                                     |
|        | ternally | asekaran |                                     |
+--------+----------+----------+-------------------------------------+
| 219871 | In-      | Akila    | Request to install TAC in           |
|        | Progress | Raj      | UEUAT28JMPBX01                      |
|        |          | asekaran |                                     |
+--------+----------+----------+-------------------------------------+
| 218526 | Waiting  | Carlos   | Add Alert and Monitoring for New    |
|        | In       | Aponte   | Billing Jobs - July Release         |
|        | ternally |          |                                     |
+--------+----------+----------+-------------------------------------+
| 211846 | Dev      | Arka     | The timestamp being reflecting in   |
|        | elopment | Sarkar   | Activity Stream Section of Customer |
|        |          |          | 360 is that of UTC instead of       |
|        |          |          | current system datetime for         |
|        |          |          | selected policy                     |
+--------+----------+----------+-------------------------------------+

+----+----------------------------------------------+-----------------+
| ** | **External Security Check**                  | **Hartford      |
| SR |                                              | URL**           |
| .  |                                              |                 |
| 14 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

External Security Checks
------------------------

**Description –** Team test Hartford External/Internal URL from Non-USA
VPN and expected resulted is “User should not be able to proceed with
New Quote”.

+----+---------------------------------------------+------------------+
| ** | **IP Address**                              | **Tableau &      |
| SR |                                             | Digital          |
| .  |                                             | Analytics**      |
| 15 |                                             |                  |
| ** |                                             |                  |
+====+=============================================+==================+
+----+---------------------------------------------+------------------+

IP Tracking
-----------

   **Description -** We need to extract the Distinct QCNs by  IP Address
   (Total) for Auto, Home & Service Portals –

Auto URL –
*https://tableau/#/site/Digital/views/NewCoAutoIPAddressTracking/Overview?:iid=1*

Can set the date for the previous day and click on download

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image66.png
   :width: 6.5in
   :height: 2.99444in

Home URL –
https://tableau/#/site/Digital/views/IPAddressTracker/Overview?:iid=2

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image67.png
   :width: 6.5in
   :height: 2.76944in

Note - If the count is >5 then we need to do the Analysis by going thru
the Glassbox sessions.

+-----+------------------------------------------+-------+-------------+
| *   | **MFT Job Status – On Prem & Billing**   | **M   |             |
| *SR |                                          | FTPor |             |
| .1  |                                          | tal** |             |
| 6** |                                          |       |             |
+=====+==========================================+=======+=============+
+-----+------------------------------------------+-------+-------------+

MFT Job Status – On Prem
------------------------

**Description -** MFT Status are collected based on the MFT IDs.

-  Below are the steps to check the MFT Job Status:

i)    Open the MFT Portal:
      https://mftportal.thehartford.com:9443/security/login

ii)   After Entering username and password click on the search Button on
      the left side

iii)  Enter the MFT ID in LOB/Department/Owner/MFTID Text box

iv)   In Process Start Date there are two textboxes From and To.

v)    From will be having value of (T-1) day

vi)   To will be having value of T day

vii)  In LOB/Department/Owner/MFTID Text box enter the value in the
      format(*MFTID*) and click on Search

viii) Ensure "ProcStatus" is "Success" and Check the column
      “ProcEndDate” and update the latest date in excel

ix)   Please find the below link for the On-prem MFT Id details –

..

   `MFT_Onprem.xlsx
   (sharepoint.com) <https://thehartford.sharepoint.com/:x:/r/sites/NewCoProgram/_layouts/15/Doc.aspx?sourcedoc=%7B7A8C5A54-6963-4821-8B36-796C2608EA17%7D&file=MFT_Onprem.xlsx&action=default&mobileredirect=true>`__

x)  If the MFTID gets failed, then we need to check the reason why it
    got failed and should take the necessary action to get the report
    MFTed successfully.

xi) Team is tracking the daily ON-Prem MFT details in the below link –

..

   `On Prem MFT Job Status.xlsx
   (sharepoint.com) <https://thehartford.sharepoint.com/:x:/r/sites/NewCoProgram/_layouts/15/Doc.aspx?sourcedoc=%7B4C1BFB8C-5E90-4DF7-96C9-18CF2824D106%7D&file=On%20Prem%20MFT%20%20Job%20Status.xlsx&action=default&mobileredirect=true&cid=bf511053-ca86-4b05-b2cd-2998de8e9585&CID=2C804C30-A8E5-43E1-8CB1-5BF18F5A21D2&wdLOR=c32A80807-08DE-43C7-8AE4-CE0C4D07BA8F>`__

-  **Observations and validations:-**

i)   We need to ensure that the reports got generated for the respective
     MFT ID in the SharePoint link mentioned in Point no 9. If the
     report is generated successfully, then the report gets archived in
     the Archive -> Outbound folder.

ii)  Sometimes policies are rejected by the Vendor which will be
     available in the Prod Inbound path for APP2APP reports.

iii) If we find any issues while the reports getting generated, then the
     team will analyze the issue and take the necessary actions to get
     the reports generated successfully.

A) **MFT Job - Billing**

**Description -** MFT Status are collected based on the MFT IDs.

-  Below are the steps to check the MFT Job Status:

i)    Open the MFT Portal:
      https://mftportal.thehartford.com:9443/security/login

ii)   After Entering username and password click on the search Button on
      the left side

iii)  Enter the MFT ID in LOB/Department/Owner/MFTID Text box

iv)   In Process Start Date there are two textboxes from and to.

v)    From will be having value of t-1 day

vi)   To will be having value of t day

vii)  In LOB/Department/Owner/MFTID Text box enter the value in the
      format(*MFTID*) and click on search

viii) Ensure "ProcStatus" is "Success" and Check the column
      “ProcEndDate” and update the latest date in excel

ix)   Please find the below link for the On-prem MFT Id details –

..

   `MFT_Onprem.xlsx
   (sharepoint.com) <https://thehartford.sharepoint.com/:x:/r/sites/NewCoProgram/_layouts/15/Doc.aspx?sourcedoc=%7B7A8C5A54-6963-4821-8B36-796C2608EA17%7D&file=MFT_Onprem.xlsx&action=default&mobileredirect=true>`__

+---------------------------------------------+------------+-----------+
|                                             | MFTID      | Status on |
|                                     Billing |            | MFT       |
| Jobs                                        |            |           |
+=============================================+============+===========+
| ACH Payment Process request                 | NCBA4P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| ACH Refunds Process request                 | NCBA4P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| CC Payment Process request                  | NCBA4P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| CC Refund Process request                   | NCBA4P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| ACH Return Payment Process                  | NCBA3P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| ACH Return Refund Process                   | NCBA3P     | Success   |
|                                             |            | for 10/25 |
+---------------------------------------------+------------+-----------+
| CC Return Payment Process                   | NCBA2P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| CC Return Refund Process                    | NCBA2P     | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| DCS Check Refunds File transfer             | NCDCS1P    | Success   |
|                                             |            | for 10/28 |
+---------------------------------------------+------------+-----------+
| DCS Check Refunds Details and Status update | NCFTNB1P   | Success   |
| via DCS Feedback Process                    |            | for 10/29 |
+---------------------------------------------+------------+-----------+
| FEED file transfer (MonthlyExpenseFeed)     | NCET1P     | Success   |
|                                             |            | for 10/31 |
+---------------------------------------------+------------+-----------+
| ABA Routing Numbers / Monthly update from   | NEAB1      | Success   |
| BACIS                                       |            | for 10/25 |
+---------------------------------------------+------------+-----------+

+----+----------------------------------------------+-----------------+
| ** | **Quote Issue Volume Count**                 | **Splunk        |
| SR |                                              | Dashboard**     |
| .  |                                              |                 |
| 17 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

New Volumetric Prod Dashboard
-----------------------------

   **Description -** Team validates the Quote/Issue traffic counts on
   daily basis through this dashboard. If considerable amount of
   deviation found, then team verifies the other monitoring components
   to understand if anything impacting Newco Customers to access the
   application or commit the quote (E.g., service down, application
   unavailability etc.) and raise incident accordingly.

   This dashboard provides total Volumetric Count, Count By State, Count
   By LOB, Count By Status, Count By Time, Count by Agency, LOB Count By
   State, LOB Count By Status, Status Count By State.

URL: `NewCo_Volumetric \| Splunk 9.0.2209.4
(splunkcloud.com) <https://thehartford.splunkcloud.com/en-US/app/HIG_APP_PL/newco_volumetric?form.field1.earliest=-24h%40h&form.field1.latest=now>`__

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image68.png
   :width: 6.5in
   :height: 2.72569in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image69.png
   :width: 6.5in
   :height: 2.62014in

+----+----------------------------------------------+-----------------+
| ** | **Grafana**                                  | **Splunk        |
| SR |                                              | Dashboard**     |
| .  |                                              |                 |
| 18 |                                              |                 |
| ** |                                              |                 |
+====+==============================================+=================+
+----+----------------------------------------------+-----------------+

Grafana for Performance
-----------------------

**Description -** Using this dashboard, team validates the User Action
Performance Trends. This Dashboard consists of Performance Trend (By 90
Percentile), Volume Trend.

URL: `NewCo Production - User Action Performance Trends -
Grafana <http://wad1prfhd2010:3000/d/yUKwT9A7z/newco-production-user-action-performance-trends?orgId=1>`__

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image70.png
   :width: 6.5in
   :height: 2.57639in

.. image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image71.png
   :width: 6.5in
   :height: 2.16875in

.. |image1| image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image33.png
   :width: 6.5in
   :height: 2.99306in
.. |image2| image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image34.png
   :width: 6.5in
   :height: 3.09097in
.. |image3| image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image42.png
   :width: 3.21652in
   :height: 5.5in
.. |image4| image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image43.png
   :width: 2.89415in
   :height: 5.5in
.. |image5| image:: vertopal_2963d5e6b2064d7d97e6458e12c27d30/media/image63.png
   :width: 6.5in
   :height: 2.08333in
